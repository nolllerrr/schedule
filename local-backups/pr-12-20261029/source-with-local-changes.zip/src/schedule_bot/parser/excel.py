from __future__ import annotations

import re
from datetime import date, timedelta
from pathlib import Path
from typing import Iterable

from xml.etree.ElementTree import ParseError
from zipfile import BadZipFile

from schedule_bot.parser.workbook import (
    ValueWorksheet as Worksheet, WorkbookLimits, WorkbookValues,
)

from schedule_bot.domain import Lesson, LessonSegment, ParsedSchedule


class ScheduleParseError(ValueError):
    """Raised when a workbook does not match the supported schedule layout."""


RUSSIAN_MONTHS = {
    "января": 1,
    "февраля": 2,
    "марта": 3,
    "апреля": 4,
    "мая": 5,
    "июня": 6,
    "июля": 7,
    "августа": 8,
    "сентября": 9,
    "октября": 10,
    "ноября": 11,
    "декабря": 12,
}

WEEKDAYS = {
    0: "понедельник",
    1: "вторник",
    2: "среда",
    3: "четверг",
    4: "пятница",
    5: "суббота",
    6: "воскресенье",
}

WEEKDAY_ALIASES = {
    "понедельник": "понедельник",
    "вторник": "вторник",
    "вторинк": "вторник",
    "среда": "среда",
    "четверг": "четверг",
    "пятница": "пятница",
    "суббота": "суббота",
    "воскресенье": "воскресенье",
}

GROUP_PATTERN = re.compile(r"^[А-ЯЁA-Z]{1,4}\s*-\s*\d{1,3}$", re.IGNORECASE)
LESSON_PATTERN = re.compile(r"^(?P<number>\d+)\s*пара$", re.IGNORECASE)
CLASS_HOUR_PATTERN = re.compile(r"^кл\.?\s*час$", re.IGNORECASE)
TIME_PATTERN = re.compile(
    r"(?P<start>\d{1,2}[.:]\d{2})\s*[-–—]\s*(?P<end>\d{1,2}[.:]\d{2})"
)


def normalize_text(value: object) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\xa0", " ")).strip()


def normalize_group(value: object) -> str:
    text = normalize_text(value).upper()
    return re.sub(r"\s*-\s*", "-", text)


def parse_filename_date_range(filename: str) -> tuple[date, date]:
    name = Path(filename).stem
    full = re.search(
        r"(?<![\d.])(?P<sd>\d{1,2})\.(?P<sm>\d{1,2})\.(?P<sy>\d{2,4})"
        r"\s*-\s*"
        r"(?P<ed>\d{1,2})\.(?P<em>\d{1,2})\.(?P<ey>\d{2,4})",
        name,
    )
    if full:
        sy = _expand_year(int(full.group("sy")))
        ey = _expand_year(int(full.group("ey")))
        return (
            date(sy, int(full.group("sm")), int(full.group("sd"))),
            date(ey, int(full.group("em")), int(full.group("ed"))),
        )

    partial = re.search(
        r"(?<![\d.])(?P<sd>\d{1,2})\.(?P<sm>\d{1,2})\.?\s*-\s*"
        r"(?P<ed>\d{1,2})\.(?P<em>\d{1,2})\.(?P<year>\d{2,4})(?!\d)",
        name,
    )
    if partial:
        year = _expand_year(int(partial.group("year")))
        start_month = int(partial.group("sm"))
        end_month = int(partial.group("em"))
        start_year = year - 1 if start_month > end_month else year
        return (
            date(start_year, start_month, int(partial.group("sd"))),
            date(year, end_month, int(partial.group("ed"))),
        )

    compact = re.search(
        r"(?<![\d.])(?P<sd>\d{1,2})\.\s*-\s*(?P<ed>\d{1,2})\."
        r"(?P<month>\d{1,2})\.(?P<year>\d{2,4})",
        name,
    )
    if compact:
        year = _expand_year(int(compact.group("year")))
        month = int(compact.group("month"))
        start_day = int(compact.group("sd"))
        end_day = int(compact.group("ed"))
        end_date = date(year, month, end_day)
        # In a compact range the month belongs to the ending date. When the
        # starting day is larger, the range began in the previous month.
        start_month = (
            date(year, month, 1) - timedelta(days=1)
            if start_day > end_day
            else end_date
        )
        return (
            date(start_month.year, start_month.month, start_day),
            end_date,
        )

    single = re.search(
        r"(?<![\d.\-])(?P<day>\d{1,2})\.(?P<month>\d{1,2})\."
        r"(?P<year>\d{2,4})(?!\d)",
        name,
    )
    if single:
        lesson_date = date(
            _expand_year(int(single.group("year"))),
            int(single.group("month")),
            int(single.group("day")),
        )
        return lesson_date, lesson_date
    raise ScheduleParseError(
        f"Cannot determine the schedule date range from filename: {filename}"
    )


def parse_sheet_date(title: str) -> date | None:
    normalized = normalize_text(title).lower()
    match = re.search(
        r"(?P<day>\d{1,2})\s+(?P<month>[а-яё]+)\s+(?P<year>\d{4})",
        normalized,
    )
    if match and match.group("month") in RUSSIAN_MONTHS:
        return date(
            int(match.group("year")),
            RUSSIAN_MONTHS[match.group("month")],
            int(match.group("day")),
        )
    numeric = re.search(
        r"(?P<day>\d{1,2})\.(?P<month>\d{1,2})\.(?P<year>\d{2,4})",
        normalized,
    )
    if numeric:
        return date(
            _expand_year(int(numeric.group("year"))),
            int(numeric.group("month")),
            int(numeric.group("day")),
        )
    return None


def _expand_year(value: int) -> int:
    return value + 2000 if value < 100 else value


class ExcelScheduleParser:
    def __init__(self, *, limits: WorkbookLimits | None = None) -> None:
        self.limits = limits or WorkbookLimits()

    def parse(
        self, path: str | Path, *, source_filename: str | None = None
    ) -> ParsedSchedule:
        source_path = Path(path)
        filename = source_filename or source_path.name
        start_date, end_date = parse_filename_date_range(filename)

        try:
            with WorkbookValues(source_path, self.limits) as workbook:
                return self._parse_workbook(workbook, filename, start_date, end_date)
        except (ValueError, BadZipFile, ParseError, KeyError, IndexError, TypeError, OverflowError) as error:
            if isinstance(error, ScheduleParseError):
                raise
            raise ScheduleParseError(f"Cannot read schedule workbook: {error}") from error

    def _parse_workbook(
        self, workbook: WorkbookValues, filename: str, start_date: date, end_date: date,
    ) -> ParsedSchedule:
        lessons: list[Lesson] = []
        parsed_dates: list[date] = []
        warnings: list[str] = []
        validation_errors: list[str] = []
        date_groups: dict[date, tuple[str, ...]] = {}
        confirmed_empty_dates: list[date] = []
        for title, part in workbook.sheets:
            sheet_date = parse_sheet_date(title)
            if sheet_date is None:
                warnings.append(
                    f"Лист {title!r} пропущен: дата не распознана"
                )
                continue
            if not start_date <= sheet_date <= end_date:
                continue

            worksheet = workbook.read_sheet(title, part)

            group_columns = self._find_group_columns(worksheet)
            if not group_columns:
                validation_errors.append(
                    f"Лист {worksheet.title!r} пропущен: группы не найдены"
                )
                continue

            day_row = self._find_matching_day_row(
                worksheet, sheet_date, group_columns
            )
            if day_row is None:
                validation_errors.append(
                    f"Лист {worksheet.title!r} пропущен: блок дня не найден"
                )
                continue

            if sheet_date in date_groups:
                validation_errors.append(f"Дата {sheet_date} повторяется на листах")
            date_groups[sheet_date] = tuple(group for _, group in group_columns)
            empty_confirmed = (
                normalize_text(worksheet['A1'].value).upper() == "ЗАНЯТИЙ НЕТ"
            )
            if empty_confirmed:
                confirmed_empty_dates.append(sheet_date)
            validation_errors.extend(
                self._validate_day_layout(
                    worksheet, day_row=day_row, group_columns=group_columns,
                    empty_confirmed=empty_confirmed,
                )
            )
            parsed_dates.append(sheet_date)
            lessons.extend(
                self._parse_day(
                    worksheet,
                    sheet_date=sheet_date,
                    day_row=day_row,
                    group_columns=group_columns,
                    validation_errors=validation_errors,
                )
            )
        if not parsed_dates:
            raise ScheduleParseError("No schedule sheets were parsed")
        if not lessons and not confirmed_empty_dates and not validation_errors:
            raise ScheduleParseError("The workbook contains no lessons")

        lessons.sort(
            key=lambda item: (item.lesson_date, item.group_name, item.position)
        )
        return ParsedSchedule(
            source_filename=filename,
            start_date=start_date,
            end_date=end_date,
            dates=tuple(sorted(set(parsed_dates))),
            lessons=tuple(lessons),
            warnings=tuple(warnings),
            date_groups=date_groups,
            validation_errors=tuple(validation_errors),
            confirmed_empty_dates=tuple(confirmed_empty_dates),
        )

    def _find_group_columns(self, worksheet: Worksheet) -> list[tuple[int, str]]:
        return self._find_group_header(worksheet)[1]

    def _find_group_header(
        self, worksheet: Worksheet
    ) -> tuple[int, list[tuple[int, str]]]:
        best: list[tuple[int, str]] = []
        best_row = 0
        for row in range(1, min(worksheet.max_row, 20) + 1):
            candidates: list[tuple[int, str]] = []
            for column in range(3, worksheet.max_column + 1):
                value = normalize_group(worksheet.cell(row, column).value)
                if value and GROUP_PATTERN.fullmatch(value):
                    candidates.append((column, value))
            if len(candidates) > len(best):
                best = candidates
                best_row = row
        return best_row, best

    def _validate_day_layout(
        self,
        worksheet: Worksheet,
        *,
        day_row: int,
        group_columns: list[tuple[int, str]],
        empty_confirmed: bool,
    ) -> list[str]:
        errors: list[str] = []
        header_row, _ = self._find_group_header(worksheet)
        groups = [group for _, group in group_columns]
        if len(groups) != len(set(groups)):
            errors.append(f"Лист {worksheet.title!r}: повторяются заголовки групп")
        # Each supported group occupies four columns, starting at column C.
        stop_row = self._day_stop_row(worksheet, day_row)
        end_column = next(
            (
                column
                for column in range(3, worksheet.max_column)
                if normalize_text(
                    worksheet.cell(header_row, column).value
                ).casefold() == "группа"
                and normalize_text(
                    worksheet.cell(header_row, column + 1).value
                ).casefold() == "день недели"
            ),
            worksheet.max_column + 1,
        )
        last_column = max(
            column for column in range(3, end_column)
            if normalize_text(worksheet.cell(header_row, column).value)
            or any(
                normalize_text(worksheet.cell(row, column).value)
                for row in range(day_row, stop_row)
            )
        )
        starts = {column for column, _ in group_columns}
        for column in range(3, last_column + 1, 4):
            if column not in starts:
                errors.append(
                    f"Лист {worksheet.title!r}: не распознан заголовок "
                    f"{worksheet.cell(header_row, column).coordinate}"
                )
        if any((column - 3) % 4 for column in starts):
            errors.append(f"Лист {worksheet.title!r}: изменена ширина блока группы")
        lesson_rows = tuple(self._lesson_rows_after(worksheet, day_row))
        covered_rows = {
            row for lesson_row in lesson_rows for row in range(lesson_row, lesson_row + 4)
        }
        data_end = max(covered_rows, default=day_row - 1) + 1
        if not lesson_rows and not empty_confirmed:
            errors.append(f"Лист {worksheet.title!r}: блоки пар не распознаны")
        for row in range(day_row, stop_row):
            label = normalize_text(worksheet.cell(row, 2).value)
            has_content = any(
                normalize_text(worksheet.cell(row, column).value)
                for column in range(3, min(last_column + 4, end_column))
            )
            # Footnotes below the last pair may occupy group columns. An orphan
            # inside the pair grid or with its own clock row is schedule data.
            orphan_clock = TIME_PATTERN.search(label) or TIME_PATTERN.search(
                normalize_text(worksheet.cell(row + 1, 2).value)
            )
            if (
                row not in covered_rows
                and ((has_content and row < data_end) or orphan_clock)
            ) or (
                label and row not in lesson_rows
                and not TIME_PATTERN.search(label) and has_content
            ):
                errors.append(
                    f"Лист {worksheet.title!r}: не распознан блок пары в строке {row}"
                )
        return errors

    def _find_matching_day_row(
        self,
        worksheet: Worksheet,
        sheet_date: date,
        group_columns: list[tuple[int, str]],
    ) -> int | None:
        expected = WEEKDAYS[sheet_date.weekday()]
        candidates: list[int] = []
        for row in range(1, worksheet.max_row + 1):
            label = normalize_text(worksheet.cell(row, 1).value).lower()
            if WEEKDAY_ALIASES.get(label) == expected:
                candidates.append(row)
        if not candidates:
            return None
        return max(
            candidates,
            key=lambda row: self._day_content_score(
                worksheet, row=row, group_columns=group_columns
            ),
        )

    def _day_content_score(
        self,
        worksheet: Worksheet,
        *,
        row: int,
        group_columns: list[tuple[int, str]],
    ) -> int:
        score = 0
        for lesson_row in self._lesson_rows_after(worksheet, row):
            for start_column, _ in group_columns:
                if any(
                    normalize_text(worksheet.cell(r, c).value)
                    for r in range(lesson_row, lesson_row + 4)
                    for c in range(start_column, start_column + 4)
                ):
                    score += 1
        return score

    def _lesson_rows_after(
        self, worksheet: Worksheet, day_row: int
    ) -> Iterable[int]:
        stop_row = self._day_stop_row(worksheet, day_row)
        for row in range(day_row, stop_row):
            label = normalize_text(worksheet.cell(row, 2).value)
            if LESSON_PATTERN.fullmatch(label) or CLASS_HOUR_PATTERN.fullmatch(label):
                yield row

    @staticmethod
    def _day_stop_row(worksheet: Worksheet, day_row: int) -> int:
        stop_row = min(worksheet.max_row + 1, day_row + 33)
        for row in range(day_row + 1, stop_row):
            label = normalize_text(worksheet.cell(row, 1).value).lower()
            if label in WEEKDAY_ALIASES:
                stop_row = row
                break
        return stop_row

    def _parse_day(
        self,
        worksheet: Worksheet,
        *,
        sheet_date: date,
        day_row: int,
        group_columns: list[tuple[int, str]],
        validation_errors: list[str],
    ) -> list[Lesson]:
        lessons: list[Lesson] = []
        for position, lesson_row in enumerate(
            self._lesson_rows_after(worksheet, day_row), start=1
        ):
            lesson_label = normalize_text(worksheet.cell(lesson_row, 2).value)
            number_match = LESSON_PATTERN.fullmatch(lesson_label)
            lesson_number = int(number_match.group("number")) if number_match else None
            start_time, end_time = self._parse_time(
                worksheet.cell(lesson_row + 1, 2).value
            )

            for start_column, group_name in group_columns:
                raw_data = self._raw_block(
                    worksheet,
                    row=lesson_row,
                    column=start_column,
                )
                subject_parts = self._values(
                    worksheet,
                    rows=range(lesson_row, lesson_row + 2),
                    columns=range(start_column, start_column + 3),
                )
                teacher_parts = self._values(
                    worksheet,
                    rows=range(lesson_row + 2, lesson_row + 4),
                    columns=range(start_column, start_column + 3),
                )
                room_parts = self._values(
                    worksheet,
                    rows=range(lesson_row, lesson_row + 2),
                    columns=(start_column + 3,),
                )
                if not subject_parts:
                    if teacher_parts or room_parts:
                        validation_errors.append(
                            f"Лист {worksheet.title!r}: у {group_name}, "
                            f"{lesson_label} есть преподаватель/аудитория без предмета"
                        )
                    continue

                subject = " / ".join(subject_parts)
                teacher = " / ".join(teacher_parts) or None
                room = self._format_room(room_parts)
                subgroup = self._detect_subgroup(subject)
                try:
                    segments = self._parse_segments(
                        worksheet, row=lesson_row, column=start_column,
                        subject_parts=subject_parts, teacher_parts=teacher_parts,
                    )
                except ValueError as error:
                    validation_errors.append(
                        f"Лист {worksheet.title!r}: у {group_name}, "
                        f"{lesson_label}: {error}"
                    )
                    segments = ()
                lessons.append(
                    Lesson(
                        lesson_date=sheet_date,
                        group_name=group_name,
                        position=position,
                        lesson_label=lesson_label,
                        lesson_number=lesson_number,
                        start_time=start_time,
                        end_time=end_time,
                        subject=subject,
                        teacher=teacher,
                        room=room,
                        subgroup=subgroup,
                        raw_data=raw_data,
                        segments=segments,
                    )
                )
        return lessons

    def _parse_segments(
        self, worksheet: Worksheet, *, row: int, column: int,
        subject_parts: list[str], teacher_parts: list[str],
    ) -> tuple[LessonSegment, ...]:
        """Accept two explicit subgroup lanes; never zip independent values."""
        markers = self._detect_subgroup(" / ".join(subject_parts))
        if markers != "1,2":
            if len(teacher_parts) > 1:
                raise ValueError("неоднозначная связь нескольких преподавателей")
            return ()

        subjects = self._block_entries(
            worksheet, rows=range(row, row + 2),
            columns=range(column, column + 3),
        )
        if len(subjects) != 2 or {
            self._detect_subgroup(value) for _, _, value in subjects
        } != {"1", "2"}:
            raise ValueError("подгруппы требуют двух отдельных помеченных предметов")

        first, second = subjects
        if first[1] == second[1] and {first[0], second[0]} == {row, row + 1}:
            # Each subject row maps to the same teacher/room row below it.
            subjects.sort()
            teachers = self._lane_values(
                worksheet, rows=range(row + 2, row + 4),
                columns=range(column, column + 3), axis="row",
                lanes=((row + 2, row + 2), (row + 3, row + 3)),
            )
            rooms = self._lane_values(
                worksheet, rows=range(row, row + 2),
                columns=(column + 3,), axis="row",
                lanes=((row, row), (row + 1, row + 1)),
            )
            rooms = tuple(self._format_room([value]) if value else None for value in rooms)
            for subject_row, subject_column, _ in subjects:
                bounds = worksheet.cell_bounds(subject_row, subject_column)
                if (
                    bounds[1] != subject_row or bounds[3] != subject_row
                    or bounds[0] < column or bounds[2] > column + 2
                ):
                    raise ValueError("объединение предмета пересекает подгруппы")
        elif first[0] == second[0] and first[1] != second[1]:
            subjects.sort(key=lambda entry: entry[1])
            if subjects[0][1] != column:
                raise ValueError("не распознаны границы столбцов подгрупп")
            split = subjects[1][1]
            lanes = ((column, split - 1), (split, column + 2))
            for (subject_row, subject_column, _), (left, right) in zip(subjects, lanes):
                bounds = worksheet.cell_bounds(subject_row, subject_column)
                if (
                    bounds[0] < left or bounds[2] > right
                    or bounds[1] < row or bounds[3] > row + 1
                ):
                    raise ValueError("объединение предмета пересекает подгруппы")
            teachers = self._lane_values(
                worksheet, rows=range(row + 2, row + 4),
                columns=range(column, column + 3), axis="column", lanes=lanes,
            )
            room_entries = self._block_entries(
                worksheet, rows=range(row, row + 2), columns=(column + 3,),
            )
            if not room_entries:
                rooms = (None, None)
            elif len(room_entries) == 1:
                room_row, room_column, room_value = room_entries[0]
                bounds = worksheet.cell_bounds(room_row, room_column)
                if bounds != (column + 3, row, column + 3, row + 1):
                    raise ValueError("аудитория не связана с горизонтальными подгруппами")
                rooms = (self._format_room([room_value]),) * 2
            else:
                raise ValueError("аудитории не связаны с горизонтальными подгруппами")
        else:
            raise ValueError("неоднозначная геометрия параллельных подгрупп")

        segments = tuple(
            LessonSegment(
                subject=value, teacher=teachers[index], room=rooms[index],
                subgroup=self._detect_subgroup(value),
            )
            for index, (_, _, value) in enumerate(subjects)
        )
        return tuple(sorted(segments, key=lambda part: part.subgroup or ""))

    @staticmethod
    def _block_entries(
        worksheet: Worksheet, *, rows: Iterable[int], columns: Iterable[int],
    ) -> list[tuple[int, int, str]]:
        return [
            (row, column, value)
            for row in rows for column in columns
            if (value := normalize_text(worksheet.cell(row, column).value))
        ]

    def _lane_values(
        self, worksheet: Worksheet, *, rows: Iterable[int],
        columns: Iterable[int], axis: str,
        lanes: tuple[tuple[int, int], tuple[int, int]],
    ) -> tuple[str | None, str | None]:
        rows, columns = tuple(rows), tuple(columns)
        result: list[list[str]] = [[], []]
        for row, column, value in self._block_entries(
            worksheet, rows=rows, columns=columns,
        ):
            left, top, right, bottom = worksheet.cell_bounds(row, column)
            if (
                left < min(columns) or right > max(columns)
                or top < min(rows) or bottom > max(rows)
            ):
                raise ValueError("объединение пересекает границы поля подгруппы")
            first, last = (top, bottom) if axis == "row" else (left, right)
            for index, (lane_first, lane_last) in enumerate(lanes):
                if first <= lane_last and last >= lane_first:
                    if value not in result[index]:
                        result[index].append(value)
        if any(len(values) > 1 for values in result):
            raise ValueError("несколько значений без однозначной связи с подгруппой")
        return (
            result[0][0] if result[0] else None,
            result[1][0] if result[1] else None,
        )

    @staticmethod
    def _parse_time(value: object) -> tuple[str | None, str | None]:
        match = TIME_PATTERN.search(normalize_text(value))
        if not match:
            return None, None
        return (
            ExcelScheduleParser._normalize_clock(match.group("start")),
            ExcelScheduleParser._normalize_clock(match.group("end")),
        )

    @staticmethod
    def _normalize_clock(value: str) -> str:
        hour, minute = re.split(r"[.:]", value)
        return f"{int(hour):02d}:{int(minute):02d}"

    @staticmethod
    def _values(
        worksheet: Worksheet,
        *,
        rows: Iterable[int],
        columns: Iterable[int],
    ) -> list[str]:
        result: list[str] = []
        for row in rows:
            for column in columns:
                value = normalize_text(worksheet.cell(row, column).value)
                if value and value not in result:
                    result.append(value)
        return result

    @staticmethod
    def _raw_block(
        worksheet: Worksheet, *, row: int, column: int
    ) -> dict[str, str]:
        result: dict[str, str] = {}
        for current_row in range(row, row + 4):
            for current_column in range(column, column + 4):
                cell = worksheet.cell(current_row, current_column)
                value = normalize_text(cell.value)
                if value:
                    result[cell.coordinate] = value
        return result

    @staticmethod
    def _format_room(parts: list[str]) -> str | None:
        if not parts:
            return None
        compact = "".join(part.replace(" ", "").lower() for part in parts)
        if compact in {"сп/з", "сп/зал", "спортзал"}:
            return "спортзал"
        if len(parts) == 2 and parts[0].endswith("/"):
            return parts[0] + parts[1]
        return " / ".join(parts)

    @staticmethod
    def _detect_subgroup(subject: str) -> str | None:
        found = sorted(
            set(
                re.findall(
                    r"\b([12])\s*п\s*/?\s*гр\.?",
                    subject,
                    flags=re.IGNORECASE,
                )
            )
        )
        return ",".join(found) or None
