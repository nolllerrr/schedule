from __future__ import annotations

import html
import logging
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

from aiogram import Bot, F, Router
from aiogram.enums import ChatMemberStatus, ChatType
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    ChatMemberUpdated,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from schedule_bot.analytics import UsageAnalytics
from schedule_bot.bot.cards import (
    delete_previous_view, send_current_schedule_view, send_schedule_card, switch_schedule_view,
)
from schedule_bot.bot.menus import (
    callback_data,
    callback_parts,
    dates_page_from_action,
    dates_menu_keyboard,
    initial_dates_page,
    schedule_menu_keyboard,
    schedule_result_keyboard,
    week_menu_keyboard,
)
from schedule_bot.config import Settings
from schedule_bot.pinning import bot_can_pin, sync_chat_schedule_pin, unpin_schedule_messages
from schedule_bot.repository import ScheduleRepository
from schedule_bot.async_repository import repository_async
from schedule_bot.freshness import with_freshness
from schedule_bot.notifier import _destination_lock, migrate_group_chat
from schedule_bot.schedule_selection import current_schedule


router = Router(name="group_chats")
logger = logging.getLogger(__name__)
GROUP_MENU_PREFIX = "gnav"
GROUP_CHAT_TYPES = {"group", "supergroup"}
router.message.filter(F.chat.type.in_(GROUP_CHAT_TYPES))
router.callback_query.filter(F.message.chat.type.in_(GROUP_CHAT_TYPES))


@router.message(F.migrate_to_chat_id | F.migrate_from_chat_id)
async def group_migrated(message: Message, repository: ScheduleRepository) -> None:
    if message.migrate_to_chat_id is not None:
        old_chat_id, new_chat_id = message.chat.id, message.migrate_to_chat_id
    else:
        old_chat_id, new_chat_id = message.migrate_from_chat_id, message.chat.id
    await migrate_group_chat(repository, old_chat_id, new_chat_id)


def chat_type_value(value: ChatType | str) -> str:
    """Normalize aiogram versions that expose Chat.type as enum or string."""
    return str(getattr(value, "value", value))


def group_selection_keyboard(
    groups: list[str], owner_id: int
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for index in range(0, len(groups), 3):
        rows.append(
            [
                InlineKeyboardButton(
                    text=group,
                    callback_data=callback_data(
                        "group_setup", owner_id, group
                    ),
                )
                for group in groups[index : index + 3]
            ]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _is_chat_admin(bot: Bot, chat_id: int, user_id: int) -> bool:
    member = await bot.get_chat_member(chat_id, user_id)
    return member.status in {
        ChatMemberStatus.CREATOR,
        ChatMemberStatus.ADMINISTRATOR,
    }


async def _require_admin(message: Message, bot: Bot) -> bool:
    if message.from_user and await _is_chat_admin(
        bot, message.chat.id, message.from_user.id
    ):
        return True
    await message.answer("Эта настройка доступна только администраторам чата.")
    return False


async def _bot_can_pin(bot: Bot, chat_id: int) -> bool:
    return await bot_can_pin(bot, chat_id)


async def _publish_and_pin_schedule(
    bot: Bot,
    repository: ScheduleRepository,
    settings: Settings,
    *,
    chat_id: int,
    target: str,
) -> bool | None:
    """Publish the schedule that is relevant at the current local time."""
    return await sync_chat_schedule_pin(
        bot,
        repository,
        chat_id=chat_id,
        target=target,
        now=_now(settings),
        stale_after_minutes=getattr(settings, "schedule_stale_after_minutes", 120),
    )


@router.message(Command("setup"))
async def setup_group(
    message: Message,
    bot: Bot,
    repository: ScheduleRepository,
) -> None:
    if not await _require_admin(message, bot):
        return
    groups = await repository_async(repository).list_groups()
    if not groups:
        await message.answer("Расписание ещё не загружено. Попробуйте позже.")
        return
    await message.answer(
        "Выберите учебную группу для этого чата:",
        reply_markup=group_selection_keyboard(groups, message.from_user.id),
    )


@router.callback_query(F.data.startswith("group_setup:"))
async def save_group_setup(
    callback: CallbackQuery,
    bot: Bot,
    repository: ScheduleRepository,
    settings: Settings,
    analytics: UsageAnalytics,
) -> None:
    if callback.message is None or not await _is_chat_admin(
        bot, callback.message.chat.id, callback.from_user.id
    ):
        await callback.answer(
            "Настраивать бота может только администратор.", show_alert=True
        )
        return
    setup_parts = callback_parts(callback.data, "group_setup")
    if setup_parts is None:
        await callback.answer(
            "Это меню настройки устарело. Выполните /setup ещё раз.",
            show_alert=True,
        )
        return
    owner_id, target = setup_parts
    if owner_id != callback.from_user.id:
        await callback.answer(
            "Выбирать группу может только тот, кто открыл это меню.",
            show_alert=True,
        )
        return
    if target not in await repository_async(repository).list_groups():
        await callback.answer("Эта группа больше не найдена.", show_alert=True)
        return

    chat_id = callback.message.chat.id
    previous_profile = await repository_async(repository).get_chat_profile(chat_id)
    previous_target = (
        str(previous_profile["target"]) if previous_profile is not None else None
    )
    target_changed = previous_target is not None and previous_target != target
    tracked_pin = (
        previous_profile is not None
        and (
            previous_profile.get("last_pinned_message_id") is not None
            or previous_profile.get("pending_pin_message_id") is not None
        )
    )
    pin_enabled = bool(previous_profile and previous_profile["pin_enabled"])
    pin_removed = True

    # Enabled pins keep the old schedule until its replacement is pinned.
    # Disabled pins can still have tracked messages left by a previous failure.
    if target_changed and tracked_pin and not pin_enabled:
        pin_removed = await unpin_schedule_messages(
            bot,
            repository,
            chat_id=chat_id,
        )

    async with _destination_lock(repository, "chat", chat_id):
        await repository_async(repository).save_chat_profile(
            chat_id,
            chat_type=chat_type_value(callback.message.chat.type),
            chat_title=callback.message.chat.title,
            target=target,
            configured_by=callback.from_user.id,
        )

    pin_result: bool | None = None
    callback_notice = ""
    callback_alert = False
    if target_changed and tracked_pin and not pin_removed:
        callback_notice = (
            "Группа изменена, но старое расписание не удалось открепить. "
            "Проверьте права бота."
        )
        callback_alert = True
    elif target_changed and pin_enabled:
        pin_result = await _publish_and_pin_schedule(
            bot,
            repository,
            settings,
            chat_id=chat_id,
            target=target,
        )
        if pin_result is True:
            callback_notice = "Группа изменена, новое расписание закреплено."
        elif pin_result is None:
            callback_notice = (
                "Группа изменена. Новое расписание будет закреплено после публикации."
            )
        else:
            callback_notice = (
                "Группа изменена, но новое расписание не удалось закрепить. "
                "Проверьте права бота."
            )
            callback_alert = True
    elif target_changed and tracked_pin:
        callback_notice = "Группа изменена, старое расписание откреплено."

    await analytics.track(
        "group_configured",
        actor_id=chat_id,
        actor_kind="chat",
        chat_type=chat_type_value(callback.message.chat.type),
        properties={
            "target_changed": target_changed,
            "pin_enabled": pin_enabled,
            "old_pin_removed": pin_removed,
            "new_pin_result": pin_result,
        },
    )
    await callback.message.edit_text(
        group_menu_text(await repository_async(repository).get_chat_profile(chat_id)),
        reply_markup=schedule_menu_keyboard(
            GROUP_MENU_PREFIX,
            callback.from_user.id,
            include_settings=True,
        ),
    )
    await callback.answer(callback_notice, show_alert=callback_alert)


def group_menu_text(profile: dict[str, object] | None) -> str:
    if profile is None:
        return "Чат ещё не настроен. Администратор должен выполнить /setup."
    return (
        "📚 <b>Расписание группы</b>\n"
        f"Группа: <b>{html.escape(str(profile['target']))}</b>\n\n"
        "Выберите период:"
    )


def group_settings_keyboard(
    owner_id: int,
    profile: dict[str, object],
) -> InlineKeyboardMarkup:
    notifications = "вкл" if profile["notifications"] else "выкл"
    pin = "вкл" if profile["pin_enabled"] else "выкл"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"Уведомления: {notifications}",
                    callback_data=callback_data(
                        GROUP_MENU_PREFIX, owner_id, "toggle_notifications"
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    text=f"Закрепление: {pin}",
                    callback_data=callback_data(
                        GROUP_MENU_PREFIX, owner_id, "toggle_pin"
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    text="Сменить учебную группу",
                    callback_data=callback_data(
                        GROUP_MENU_PREFIX, owner_id, "change_group"
                    ),
                )
            ],
            [
                InlineKeyboardButton(
                    text="← К расписанию",
                    callback_data=callback_data(
                        GROUP_MENU_PREFIX, owner_id, "root"
                    ),
                )
            ],
        ]
    )


def group_settings_text(profile: dict[str, object]) -> str:
    return (
        "⚙️ <b>Настройки чата</b>\n\n"
        f"Группа: <b>{html.escape(str(profile['target']))}</b>\n"
        f"Уведомления: {'включены' if profile['notifications'] else 'выключены'}\n"
        f"Закрепление: {'включено' if profile['pin_enabled'] else 'выключено'}"
    )


async def _edit_group_message(
    callback: CallbackQuery,
    text: str,
    reply_markup: InlineKeyboardMarkup,
) -> None:
    if callback.message is None:
        return
    if getattr(callback.message, "photo", None):
        await callback.message.answer(text, reply_markup=reply_markup)
        try:
            await callback.message.delete()
        except TelegramAPIError as error:
            logger.warning("Previous group schedule card could not be deleted (%s)", type(error).__name__)
        return
    try:
        await callback.message.edit_text(text, reply_markup=reply_markup)
    except TelegramBadRequest as error:
        if "message is not modified" not in str(error).casefold():
            raise


@router.message(Command("menu"))
async def open_group_menu(
    message: Message,
    repository: ScheduleRepository,
    settings: Settings | None = None,
) -> None:
    if message.from_user is None:
        return
    profile = await repository_async(repository).get_chat_profile(message.chat.id)
    if profile is None or not bool(profile["active"]):
        await message.answer(
            "Чат ещё не настроен. Администратор должен выполнить /setup."
        )
        return
    target = str(profile["target"])
    selected = await repository_async(repository).call(
        current_schedule, repository, role="student", target=target, now=_now(settings),
    )
    if selected is not None:
        lesson_date, lessons = selected
        await send_current_schedule_view(
            message, repository, settings, owner_id=message.from_user.id,
            target=target, lesson_date=lesson_date, lessons=lessons, prefix=GROUP_MENU_PREFIX,
        )
        return
    await message.answer(
        await with_freshness("Ближайшее расписание с занятиями пока не опубликовано.", repository, settings),
        reply_markup=schedule_menu_keyboard(
            GROUP_MENU_PREFIX,
            message.from_user.id,
            include_settings=True,
        ),
    )


@router.callback_query(F.data.startswith(f"{GROUP_MENU_PREFIX}:"))
async def group_menu_action(
    callback: CallbackQuery,
    bot: Bot,
    repository: ScheduleRepository,
    settings: Settings,
    analytics: UsageAnalytics,
) -> None:
    parsed = callback_parts(callback.data, GROUP_MENU_PREFIX)
    if parsed is None or callback.message is None:
        await callback.answer("Кнопка устарела.", show_alert=True)
        return
    owner_id, action = parsed
    if owner_id == 0 and (action.startswith("view_") or action == "root"):
        owner_id = callback.from_user.id
    if owner_id != callback.from_user.id:
        await callback.answer(
            "Это меню открыл другой пользователь. Отправьте /menu, чтобы открыть своё.",
            show_alert=True,
        )
        return
    profile = await repository_async(repository).get_chat_profile(callback.message.chat.id)
    if profile is None or not bool(profile["active"]):
        await callback.answer("Чат ещё не настроен.", show_alert=True)
        return

    if action.startswith("view_"):
        await switch_schedule_view(
            callback, repository, settings, owner_id=owner_id, role="student",
            target=str(profile["target"]), action=action, prefix=GROUP_MENU_PREFIX,
        )
        return

    if action == "root":
        await _edit_group_message(
            callback,
            await with_freshness(group_menu_text(profile), repository, settings),
            schedule_menu_keyboard(
                GROUP_MENU_PREFIX, owner_id, include_settings=True
            ),
        )
        await callback.answer()
        return

    admin_actions = {
        "settings",
        "toggle_notifications",
        "toggle_pin",
        "change_group",
    }
    if action in admin_actions:
        callback_notice: str | None = None
        callback_alert = False
        if not await _is_chat_admin(bot, callback.message.chat.id, owner_id):
            await callback.answer(
                "Настройки доступны только администраторам чата.",
                show_alert=True,
            )
            return
        if action == "toggle_notifications":
            async with _destination_lock(repository, "chat", callback.message.chat.id):
                await repository_async(repository).set_chat_notifications(
                    callback.message.chat.id,
                    not bool(profile["notifications"]),
                )
            profile = await repository_async(repository).get_chat_profile(callback.message.chat.id)
            await analytics.track(
                "notifications_toggled",
                actor_id=callback.message.chat.id,
                actor_kind="chat",
                chat_type=chat_type_value(callback.message.chat.type),
                properties={"enabled": bool(profile["notifications"])},
            )
        elif action == "toggle_pin":
            enabled = not bool(profile["pin_enabled"])
            if enabled and not await _bot_can_pin(bot, callback.message.chat.id):
                await callback.answer(
                    "Сначала выдайте боту право закреплять сообщения.",
                    show_alert=True,
                )
                return
            pins_removed = True
            if not enabled:
                pins_removed = await unpin_schedule_messages(
                    bot,
                    repository,
                    chat_id=callback.message.chat.id,
                )
                if not pins_removed:
                    callback_notice = (
                        "Закрепление выключено, но бот не смог открепить своё "
                        "сообщение. Проверьте его права администратора."
                    )
                    callback_alert = True
            await repository_async(repository).set_chat_pin(callback.message.chat.id, enabled)
            profile = await repository_async(repository).get_chat_profile(callback.message.chat.id)
            if enabled:
                pin_result = await _publish_and_pin_schedule(
                    bot,
                    repository,
                    settings,
                    chat_id=callback.message.chat.id,
                    target=str(profile["target"]),
                )
                if pin_result is True:
                    callback_notice = "Актуальное расписание опубликовано и закреплено."
                elif pin_result is None:
                    callback_notice = (
                        "Закрепление включено. Подходящего расписания пока нет — "
                        "бот закрепит его после публикации."
                    )
                else:
                    callback_notice = (
                        "Закрепление включено, но сообщение не удалось закрепить. "
                        "Проверьте права бота."
                    )
                    callback_alert = True
            elif pins_removed:
                callback_notice = "Закрепление выключено, сообщение откреплено."
            await analytics.track(
                "pin_toggled",
                actor_id=callback.message.chat.id,
                actor_kind="chat",
                chat_type=chat_type_value(callback.message.chat.type),
                properties={
                    "enabled": enabled,
                    "pins_removed": pins_removed,
                },
            )
        elif action == "change_group":
            groups = await repository_async(repository).list_groups()
            await _edit_group_message(
                callback,
                "Выберите учебную группу для этого чата:",
                group_selection_keyboard(groups, owner_id),
            )
            await callback.answer()
            return

        await _edit_group_message(
            callback,
            group_settings_text(profile),
            group_settings_keyboard(owner_id, profile),
        )
        await callback.answer(
            callback_notice or "",
            show_alert=callback_alert,
        )
        return

    today_value = _today(settings)
    target = str(profile["target"])
    if action.startswith("card_"):
        await send_schedule_card(
            callback, repository, settings, role="student", target=target, action=action,
        )
        return
    dates_page = dates_page_from_action(action)
    if dates_page is not None:
        dates = await repository_async(repository).published_dates()
        if not dates:
            await callback.answer("В базе пока нет расписания.", show_alert=True)
            return
        if action == "dates":
            dates_page = initial_dates_page(dates, today_value)
        await _edit_group_message(
            callback,
            "📅 <b>Выберите дату</b>",
            dates_menu_keyboard(GROUP_MENU_PREFIX, owner_id, dates, page=dates_page),
        )
        await callback.answer()
        return

    if action == "week":
        end = today_value + timedelta(days=6)
        published_dates = [
            value
            for value in await repository_async(repository).available_dates(from_date=today_value, limit=14)
            if today_value <= value <= end
        ]
        dates = [
            lesson_date
            for lesson_date in published_dates
            if await repository_async(repository).lessons_for(
                role="student", target=target, lesson_date=lesson_date
            )
        ]
        text = (
            "📅 <b>Расписание на неделю</b>\n"
            f"Группа: <b>{html.escape(target)}</b>\n\n"
        )
        if not dates:
            text += "На ближайшие семь дней занятий нет."
            keyboard = schedule_result_keyboard(
                GROUP_MENU_PREFIX,
                owner_id,
                include_settings=True,
            )
        else:
            text += "Выберите день:"
            keyboard = week_menu_keyboard(GROUP_MENU_PREFIX, owner_id, dates)
        await _edit_group_message(
            callback,
            await with_freshness(text, repository, settings),
            keyboard,
        )
        await callback.answer()
        return

    lesson_date: date | None = None
    scope = action
    if action == "today":
        lesson_date = today_value
    elif action == "tomorrow":
        lesson_date = today_value + timedelta(days=1)
    elif action.startswith("date_"):
        try:
            lesson_date = date.fromisoformat(action.removeprefix("date_"))
            scope = "date"
        except ValueError:
            pass
    elif action.startswith("weekdate_"):
        try:
            lesson_date = date.fromisoformat(action.removeprefix("weekdate_"))
            scope = "week"
        except ValueError:
            pass

    if lesson_date is None:
        await callback.answer("Кнопка устарела.", show_alert=True)
        return

    lessons = await repository_async(repository).lessons_for(
        role="student", target=target, lesson_date=lesson_date
    )
    await send_current_schedule_view(
        callback.message, repository, settings, owner_id=owner_id,
        target=target, lesson_date=lesson_date, lessons=lessons, prefix=GROUP_MENU_PREFIX,
    )
    await delete_previous_view(callback.message)
    await analytics.track(
        "schedule_requested",
        actor_id=owner_id,
        actor_kind="user",
        chat_type=chat_type_value(callback.message.chat.type),
        properties={
            "scope": scope,
            "result": "found" if lessons else "empty",
            "lesson_count": len(lessons),
        },
    )
    await callback.answer()


def _today(settings: Settings) -> date:
    return _now(settings).date()


def _now(settings: Settings | None) -> datetime:
    return datetime.now(ZoneInfo(getattr(settings, "timezone", "Europe/Moscow")))


@router.message(Command("help"))
async def group_help(message: Message) -> None:
    await message.answer(
        "ℹ️ <b>Помощь</b>\n\n"
        "/menu — открыть карточку актуального расписания в этом чате\n"
        "/setup — выбрать учебную группу, только для администраторов\n"
        "/help — показать эту справку\n\n"
        "Кнопками меню может пользоваться только открывший его участник. "
        "Настройки уведомлений, закрепления и группы доступны администраторам "
        "через кнопку «Настройки чата»."
    )


@router.my_chat_member()
async def bot_membership_changed(
    event: ChatMemberUpdated,
    repository: ScheduleRepository,
) -> None:
    if event.chat.type not in GROUP_CHAT_TYPES:
        return
    if event.new_chat_member.status in {
        ChatMemberStatus.LEFT,
        ChatMemberStatus.KICKED,
    }:
        async with _destination_lock(repository, "chat", event.chat.id):
            await repository_async(repository).deactivate_chat(event.chat.id)
