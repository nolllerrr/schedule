from datetime import date
from pathlib import Path

import pytest

from schedule_bot.parser.excel import (
    ExcelScheduleParser,
    normalize_group,
    parse_filename_date_range,
)


def test_compact_filename_date_range() -> None:
    assert parse_filename_date_range("21.-23.09.2026.xlsx") == (
        date(2026, 9, 21),
        date(2026, 9, 23),
    )


def test_compact_filename_date_range_across_months() -> None:
    assert parse_filename_date_range("28.-01.10.2026.xlsx") == (
        date(2026, 9, 28),
        date(2026, 10, 1),
    )
    assert parse_filename_date_range("30.-02.01.2027.xlsx") == (
        date(2026, 12, 30),
        date(2027, 1, 2),
    )


def test_full_filename_date_range() -> None:
    assert parse_filename_date_range("14.09.26-18.09.26.xlsx") == (
        date(2026, 9, 14),
        date(2026, 9, 18),
    )


@pytest.mark.parametrize("filename", ["05.10.2026.xlsx", "05.10.26.xlsx"])
def test_single_day_filename(filename: str) -> None:
    assert parse_filename_date_range(filename) == (date(2026, 10, 5),) * 2


@pytest.mark.parametrize("filename", [
    "28.09.-02.10.2026.xlsx", "28.09-02.10.2026.xlsx",
])
def test_filename_range_with_shared_year(filename: str) -> None:
    assert parse_filename_date_range(filename) == (
        date(2026, 9, 28), date(2026, 10, 2),
    )


def test_filename_range_with_shared_year_across_new_year() -> None:
    assert parse_filename_date_range("30.12.-02.01.2027.xlsx") == (
        date(2026, 12, 30), date(2027, 1, 2),
    )


def test_group_normalization() -> None:
    assert normalize_group(" Т -21 ") == "Т-21"


def test_workbook_is_limited_by_filename_range(schedule_workbook: Path) -> None:
    parsed = ExcelScheduleParser().parse(schedule_workbook)

    assert parsed.dates == (
        date(2026, 9, 21),
        date(2026, 9, 22),
        date(2026, 9, 23),
    )
    assert len(parsed.groups) == 4
    assert "Т-21" in parsed.groups
    assert all(parsed.start_date <= lesson.lesson_date <= parsed.end_date for lesson in parsed.lessons)


def test_first_lesson_for_pd12(schedule_workbook: Path) -> None:
    parsed = ExcelScheduleParser().parse(schedule_workbook)
    lesson = next(
        item
        for item in parsed.lessons
        if item.lesson_date == date(2026, 9, 22)
        and item.group_name == "ПД-12"
        and item.lesson_number == 1
    )

    assert lesson.start_time == "09:00"
    assert lesson.end_time == "10:30"
    assert lesson.subject == "Теория гос. и права"
    assert lesson.teacher == "Булаева В.В."
    assert lesson.room == "43"


def test_template_data_outside_matching_day_is_ignored(
    schedule_workbook: Path,
) -> None:
    parsed = ExcelScheduleParser().parse(schedule_workbook)

    monday_pd12 = [
        item
        for item in parsed.lessons
        if item.lesson_date == date(2026, 9, 21) and item.group_name == "ПД-12"
    ]
    assert monday_pd12
    assert monday_pd12[0].subject.startswith("МДК.01.03")
    assert all("Экономика организ." not in item.subject for item in monday_pd12)
